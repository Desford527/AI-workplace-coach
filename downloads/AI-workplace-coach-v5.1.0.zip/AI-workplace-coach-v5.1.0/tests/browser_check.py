"""Real Chromium end-to-end tests against a clearly identified model TEST DOUBLE."""
import json
import os
import pathlib
import subprocess
import socket
import sys
import tempfile
import time
import urllib.request
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from fake_provider import start,Provider
from playwright.sync_api import sync_playwright,expect
ROOT=pathlib.Path(__file__).resolve().parents[1]
ART=pathlib.Path(os.environ.get('COACH_TEST_ARTIFACTS','/tmp/workplace-browser-artifacts'));ART.mkdir(exist_ok=True,parents=True)
with tempfile.TemporaryDirectory() as data:
    mock=start();env={**os.environ,'COACH_DATA_ROOT':data,'AHC_NO_OPEN':'1','COACH_DISABLE_BUNDLED_DEFAULTS':'1'}
    with socket.socket() as probe:
        probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
    process=subprocess.Popen([sys.executable,'server.py',str(port)],cwd=ROOT,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        url='http://127.0.0.1:'+str(port)
        for _ in range(80):
            try:
                urllib.request.urlopen(url+'/api/workplace/workspace').close();break
            except Exception:time.sleep(.1)
        else:raise RuntimeError('Server did not start')
        with sync_playwright() as pw:
            browser=pw.chromium.launch(executable_path=os.environ.get('COACH_CHROMIUM','/usr/bin/chromium'),headless=True)
            context=browser.new_context(viewport={'width':1440,'height':1000},accept_downloads=True)
            page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
            page.goto(url);expect(page.locator('#sceneTitle')).to_contain_text('项目进度');page.screenshot(path=str(ART/'desktop-home.png'),full_page=True)
            assert page.locator('#start').is_enabled()
            # No key/config: genuine error, no fake opening.
            page.click('#start');expect(page.locator('#globalError')).to_contain_text('API 设置');assert page.locator('.bubble').count()==0
            page.click('#apiOpen');expect(page.locator('#apiName')).to_have_value('DeepSeek527');expect(page.locator('#apiURL')).to_have_value('https://api.deepseek.com');expect(page.locator('#apiModel')).to_have_value('deepseek-flash');expect(page.locator('#apiKey')).to_have_value('');page.fill('#apiName','浏览器验收 · 测试替身');page.fill('#apiURL',f'http://127.0.0.1:{mock.server_port}/v1');page.fill('#apiModel','dialog-model');page.fill('#apiReviewModel','review-model');page.click('#apiForm button[type=submit]');expect(page.locator('#apiStatus')).to_contain_text('已保存');page.click('#apiTest');expect(page.locator('#apiStatus')).to_contain_text('连接测试通过');page.click('[data-close=apiDialog]')
            # Multi-config add/switch.
            page.click('#apiOpen');page.click('#apiNew');page.fill('#apiName','第二配置');page.fill('#apiURL',f'http://127.0.0.1:{mock.server_port}/custom/chat/completions');page.fill('#apiModel','second-model');page.click('#apiForm button[type=submit]');expect(page.locator('#apiStatus')).to_contain_text('已保存');options=page.locator('#apiSelect option').all();assert len(options)==3
            first=page.locator('#apiSelect option').nth(1).get_attribute('value');page.select_option('#apiSelect',first);page.click('#apiActivate');expect(page.locator('#apiBadge')).to_have_text('浏览器验收 · 测试替身');page.click('[data-close=apiDialog]')
            # Object create/edit and snapshot freeze.
            page.click('[data-tab=objects]');page.click('#newObject');page.fill('[name=name]','协作对象');page.fill('[name=role]','项目协作伙伴');page.fill('[name=goals]','保障交付');page.fill('[name=standards]','事实明确、行动可执行');page.fill('[name=style]','合作且直接');page.click('#objectForm button');expect(page.locator('#objectDialog')).not_to_be_visible();expect(page.locator('#objectCards')).to_contain_text('协作对象')
            page.click('[data-tab=practice]');Provider.calls=[];Provider.mode='flaky-json';page.click('#start');expect(page.locator('.bubble')).to_have_count(1);Provider.mode='prose';expect(page.locator('#chat')).to_contain_text('请说明方案');page.fill('#reply','我建议先验证，已完成8项测试，我负责明天更新结果。');page.click('#send');expect(page.locator('.bubble')).to_have_count(3);page.fill('#reply','需要您确认优先级，剩余风险由双方共同核查。');page.click('#send');expect(page.locator('.bubble')).to_have_count(5)
            page.locator('.bubble details summary').first.click();expect(page.locator('.interpretation').first).to_be_visible()
            page.reload();expect(page.locator('.bubble')).to_have_count(5);page.screenshot(path=str(ART/'desktop-training.png'),full_page=True)
            # Portrait fails after successful review, retained and retried.
            Provider.mode='portrait-fail';page.click('#end');expect(page.locator('#review')).to_be_visible();expect(page.locator('.bigscore')).to_contain_text('59');expect(page.locator('.round')).to_have_count(2);expect(page.locator('#review')).to_contain_text('长期画像生成失败');page.screenshot(path=str(ART/'desktop-review.png'),full_page=True)
            Provider.mode='ok';page.click('[data-tab=portrait]');page.click('#portraitRetry');expect(page.locator('#portraitContent')).to_contain_text('2 条回应');page.reload();page.click('[data-tab=portrait]');expect(page.locator('#portraitContent')).to_contain_text('2 条回应')
            # Export offline HTML contains SVG, all messages, and no API secrets.
            page.click('[data-tab=practice]')
            with page.expect_download() as dl:page.click('#exportHTML')
            export=ART/'review.html';dl.value.save_as(export);content=export.read_text();assert '<svg' in content and '我建议先验证' in content and '原话三层解读' in content and 'apiKey' not in content
            page.emulate_media(media='print');page.pdf(path=str(ART/'review.pdf'),format='A4',print_background=True);page.emulate_media(media='screen');assert (ART/'review.pdf').stat().st_size>10000
            report=context.new_page();report.route('**/*',lambda route:route.abort());report.set_content(content);expect(report.locator('.radar')).to_be_visible();assert report.locator('details:not([open])').count()==0;assert report.locator('link,script,img[src]').count()==0;report.screenshot(path=str(ART/'standalone-report.png'),full_page=True);report.close()
            # English training with a failed send and a single retry.
            page.click('#again');page.click('[data-category=english]');page.click('[data-scene=en-delay]');page.click('#start');expect(page.locator('#chat')).to_contain_text('What evidence');Provider.mode='http';page.fill('#reply','I will send an update by Friday.');page.click('#send');expect(page.locator('#sessionError')).to_contain_text('HTTP 503');expect(page.locator('.bubble.user')).to_have_count(1);assert page.locator('#send').is_disabled();Provider.mode='ok';page.click('#retry');expect(page.locator('.bubble')).to_have_count(3);expect(page.locator('.bubble.user')).to_have_count(1);page.click('#end');expect(page.locator('#review')).to_be_visible();expect(page.locator('.demo')).to_contain_text('I will confirm')
            # Mobile layout and radar labels.
            page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(ART/'mobile-review.png'),full_page=True)
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'), 'mobile page has horizontal overflow'
            assert page.locator('.radar text').count()==11
            page.click('#back');page.screenshot(path=str(ART/'mobile-home.png'),full_page=True);assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
            # Archived records remain inspectable, newer rounds do not reuse old messages.
            page.click('[data-tab=history]');expect(page.locator('#records .record')).to_have_count(2);page.locator('#records [data-open-session]').first.click();expect(page.locator('#chat')).to_contain_text('I will send an update')
            page.click('#back');page.click('#start');expect(page.locator('.bubble')).to_have_count(1)
            Provider.mode='http';page.fill('#reply','Keep this reply when changing API.');page.click('#send');expect(page.locator('#sessionError')).to_contain_text('HTTP 503');Provider.mode='ok'
            page.click('#apiOpen');page.click('#apiNew');page.fill('#apiName','修复回归配置');page.fill('#apiURL',f'http://127.0.0.1:{mock.server_port}/v1');page.fill('#apiModel','replacement-model');page.click('#apiForm button[type=submit]');expect(page.locator('#apiStatus')).to_contain_text('已保存');page.select_option('#apiSelect',first);page.once('dialog',lambda d:d.accept());page.click('#apiDelete');expect(page.locator('#apiBadge')).to_have_text('修复回归配置');page.click('#apiTest');expect(page.locator('#apiStatus')).to_contain_text('本轮仍绑定旧配置');page.click('[data-close=apiDialog]');expect(page.locator('#sessionError')).to_contain_text('旧 API 配置已不存在');page.click('#useCurrentAPI');page.click('#retry');expect(page.locator('.bubble')).to_have_count(3);expect(page.locator('.bubble.user')).to_have_count(1);expect(page.locator('#sessionError')).not_to_be_visible()
            page.once('dialog',lambda d:d.accept());page.click('#cancel');expect(page.locator('#sessionMeta')).to_contain_text('已中断');assert page.locator('#exportHTML').is_hidden();assert page.locator('#print').is_hidden();assert page.locator('#exportJSON').is_visible()
            # Ending always enters the review page before model completion.
            page.click('#back');page.click('#start');expect(page.locator('.bubble')).to_have_count(1)
            page.fill('#reply','只做简短回答，也要进入复盘。');page.click('#send');expect(page.locator('.bubble')).to_have_count(3)
            Provider.mode='review-delay';page.click('#end');expect(page.locator('#sessionTitle')).to_have_text('本次训练复盘');expect(page.locator('#composer')).not_to_be_visible();expect(page.locator('#chat')).not_to_be_visible();expect(page.locator('#review')).to_contain_text('正在生成本轮复盘');page.screenshot(path=str(ART/'review-loading-v5.0.6.png'),full_page=True);page.reload();expect(page.locator('#review')).to_be_visible();expect(page.locator('#composer')).not_to_be_visible()
            expect(page.locator('.bigscore')).to_contain_text('59');expect(page.locator('#back')).to_be_enabled()
            # Invalid grading remains an honest failure, but never returns to chat/red banners.
            Provider.mode='ok';page.click('#back');page.click('#start');expect(page.locator('.bubble')).to_have_count(1);page.fill('#reply','复盘失败后也要保留这句原话。');page.click('#send');expect(page.locator('.bubble')).to_have_count(3)
            Provider.mode='bad-score';page.click('#end');expect(page.locator('[data-review-retry]')).to_be_enabled();expect(page.locator('#review')).to_contain_text('本轮复盘尚未生成');expect(page.locator('#sessionError')).not_to_be_visible();expect(page.locator('#chat')).not_to_be_visible();expect(page.locator('#composer')).not_to_be_visible();assert page.locator('.bigscore').count()==0;assert page.locator('#practice .error:visible').count()==0
            page.screenshot(path=str(ART/'review-retry-v5.0.6.png'),full_page=True);page.reload();expect(page.locator('[data-review-retry]')).to_be_enabled();expect(page.locator('#review')).to_contain_text('复盘失败后也要保留这句原话。')
            Provider.mode='next-long';page.click('[data-review-retry]');expect(page.locator('.bigscore')).to_contain_text('59');expect(page.locator('#review')).to_contain_text('更多模型建议（2）');assert page.locator('.bubble.user').count()==1
            # Billing and network errors are contained within the review page as well.
            Provider.mode='ok';page.click('#back');page.click('#start');expect(page.locator('.bubble')).to_have_count(1);page.fill('#reply','计费故障不应阻止进入复盘页。');page.click('#send');expect(page.locator('.bubble')).to_have_count(3)
            Provider.mode='payment';page.click('#end');expect(page.locator('[data-review-retry]')).to_be_enabled();expect(page.locator('#review')).to_contain_text('余额不足');assert page.locator('#practice .error:visible').count()==0;Provider.mode='ok';page.click('[data-review-retry]');expect(page.locator('.bigscore')).to_be_visible();expect(page.locator('#back')).to_be_enabled()
            page.click('#back');page.click('#start');expect(page.locator('.bubble')).to_have_count(1);page.fill('#reply','网络故障时这条原话也要保留。');page.click('#send');expect(page.locator('.bubble')).to_have_count(3)
            def fail_review(route):
                if route.request.post_data_json.get('operation')=='review':route.abort()
                else:route.continue_()
            page.route('**/api/workplace/action',fail_review);page.click('#end');expect(page.locator('[data-review-retry]')).to_be_enabled();expect(page.locator('#chat')).not_to_be_visible();assert page.locator('#practice .error:visible').count()==0;page.reload();expect(page.locator('#review')).to_contain_text('网络故障时这条原话也要保留。');expect(page.locator('[data-review-retry]')).to_be_enabled();page.unroute('**/api/workplace/action',fail_review);page.click('[data-review-retry]');expect(page.locator('.bigscore')).to_be_visible();expect(page.locator('#back')).to_be_enabled()
            # Even zero responses finish on review, without making up a score.
            Provider.mode='ok';page.click('#back');page.click('#start');expect(page.locator('.bubble')).to_have_count(1);page.click('#end');expect(page.locator('#review')).to_contain_text('本轮还没有你的回应');expect(page.locator('#composer')).not_to_be_visible();assert page.locator('.bigscore').count()==0;assert page.locator('#practice .error:visible').count()==0
            # Long real-shaped model output: a brief header, full details and unclipped exports.
            page.set_viewport_size({'width':1440,'height':1000})
            Provider.mode='ok';page.click('#back');page.click('[data-category=report]');page.click('#start');expect(page.locator('.bubble')).to_have_count(1)
            long_reply='我建议先验证，说明已核实的事实和待确认的风险，再与您对齐负责人、下一次更新时间以及需要协调的资源。' * 5 + '完整用户原话末尾保留标记。'
            page.fill('#reply',long_reply);page.click('#send');expect(page.locator('.bubble')).to_have_count(3)
            page.screenshot(path=str(ART/'v5.0.7-training-desktop.png'),full_page=True)
            assistant_color=page.locator('.bubble:not(.user) > p').first.evaluate('(e)=>getComputedStyle(e).backgroundColor')
            user_color=page.locator('.bubble.user > p').first.evaluate('(e)=>getComputedStyle(e).backgroundColor')
            assert assistant_color!=user_color
            Provider.mode='long-review';page.click('#end');expect(page.locator('.bigscore')).to_be_visible();expect(page.locator('#back')).to_be_enabled()
            lead=page.locator('.review-lead').inner_text();assert len(lead)<=64 and '结构完整' in lead
            assert '完整总评末尾保留标记' not in page.locator('.review-verdict').inner_text()
            assert page.locator('.overall-details').get_attribute('open') is None
            assert page.locator('.review-verdict').bounding_box()['height']<290
            expect(page.locator('.issue-grid').first.locator('.issue-card')).to_have_count(2)
            assert page.locator('.more-issues').get_attribute('open') is None
            page.locator('.overall-details > summary').click();expect(page.locator('.overall-full')).to_contain_text('完整总评末尾保留标记')
            page.locator('.overall-details > summary').click()
            sample=page.locator('.answer-improved .answer-copy').first
            assert sample.evaluate('(e)=>e.scrollHeight>e.clientHeight')
            page.locator('[data-expand-answer]').first.click();expect(page.locator('[data-expand-answer]').first).to_have_attribute('aria-expanded','true')
            assert sample.evaluate('(e)=>e.scrollHeight<=e.clientHeight+1')
            page.locator('[data-expand-answer]').first.click()
            page.screenshot(path=str(ART/'v5.0.7-review-desktop.png'),full_page=True)
            page.set_viewport_size({'width':390,'height':844})
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'), 'long review mobile overflow'
            page.screenshot(path=str(ART/'v5.0.7-review-mobile.png'),full_page=True)
            with page.expect_download() as dl:page.click('#exportHTML')
            full_export=ART/'v5.0.7-full-report.html';dl.value.save_as(full_export);full_content=full_export.read_text()
            for marker in ['完整总评末尾保留标记','完整逐轮点评末尾保留标记','完整改进示范末尾保留标记','完整用户原话末尾保留标记','第三项完整观察保留标记']:
                assert marker in full_content
            report=context.new_page();report.route('**/*',lambda route:route.abort());report.set_content(full_content)
            assert report.locator('details:not([open])').count()==0
            assert report.locator('.answer-copy').first.evaluate('(e)=>e.scrollHeight<=e.clientHeight+1')
            report.close()
            page.emulate_media(media='print');page.pdf(path=str(ART/'v5.0.7-full-report.pdf'),format='A4',print_background=True);page.emulate_media(media='screen')
            pdf_text=subprocess.check_output(['pdftotext',str(ART/'v5.0.7-full-report.pdf'),'-'],text=True)
            for marker in ['完整总评末尾保留标记','完整逐轮点评末尾保留标记','完整改进示范末尾保留标记','完整用户原话末尾保留标记','第三项完整观察保留标记']:
                assert marker in pdf_text.replace('\n',''), 'PDF missing '+marker
            assert not errors, errors
            browser.close()
        print('PASS: desktop/mobile, no-config error, API CRUD/switch/test, object CRUD, two-turn training, refresh recovery, failed-send retry, portrait failure/retry, English review, HTML/PDF export; no page errors. TEST DOUBLE only.')
        print('Artifacts:',ART)
    finally:
        process.terminate();process.wait(timeout=10);mock.shutdown();mock.server_close()
